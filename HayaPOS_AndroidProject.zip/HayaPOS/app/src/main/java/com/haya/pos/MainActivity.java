package com.haya.pos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int PERMISSION_REQUEST_CODE = 100;

    // الرابط الخاص بنظام هيا ERP
    private static final String TARGET_URL = "https://effulgent-blini-89745c.netlify.app/";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── شاشة كاملة بدون status bar ───────────────────────────────────
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        // منع إيقاف الشاشة أثناء البيع
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);

        // إخفاء شريط التنقل
        hideSystemUI();

        // طلب الصلاحيات
        requestRequiredPermissions();

        // إعداد WebView
        setupWebView();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        webView = findViewById(R.id.webview);

        WebSettings settings = webView.getSettings();

        // ── JavaScript ────────────────────────────────────────────────────
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        // ── DOM Storage (localStorage) ────────────────────────────────────
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // ── Web Bluetooth & Geolocation ───────────────────────────────────
        settings.setGeolocationEnabled(true);

        // ── أداء ─────────────────────────────────────────────────────────
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // ── واجهة ─────────────────────────────────────────────────────────
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);

        // ── User Agent ────────────────────────────────────────────────────
        // نضيف "Chrome" للـ User Agent حتى يشتغل Web Bluetooth
        String ua = settings.getUserAgentString();
        if (!ua.contains("Chrome")) {
            settings.setUserAgentString(ua + " Chrome/120.0.0.0");
        }

        // ── WebViewClient ─────────────────────────────────────────────────
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // كل الروابط تفتح داخل نفس الـ WebView
                view.loadUrl(request.getUrl().toString());
                return true;
            }
        });

        // ── WebChromeClient - المهم لـ Bluetooth والصلاحيات ──────────────
        webView.setWebChromeClient(new WebChromeClient() {

            // ── السماح بطلبات Bluetooth و Camera وغيرها ──────────────────
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // السماح بكل الصلاحيات التي تطلبها الصفحة
                request.grant(request.getResources());
            }

            // ── السماح بـ Geolocation (مطلوب لـ BLE scanning) ───────────
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin,
                    GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            // ── نافذة التنبيهات ───────────────────────────────────────────
            @Override
            public boolean onJsAlert(WebView view, String url, String message,
                    android.webkit.JsResult result) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                result.confirm();
                return true;
            }
        });

        // ── تفعيل Web Bluetooth عبر flags ────────────────────────────────
        // هذا السطر هو الفرق الأساسي عن PWABuilder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WebView.setWebContentsDebuggingEnabled(false);
        }

        // تحميل الرابط
        webView.loadUrl(TARGET_URL);
    }

    // ── طلب صلاحيات البلوتوث ─────────────────────────────────────────────
    private void requestRequiredPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions = new String[]{
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.ACCESS_FINE_LOCATION
            };
        } else {
            permissions = new String[]{
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            };
        }

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                permissionsNeeded.toArray(new String[0]),
                PERMISSION_REQUEST_CODE);
        }
    }

    // ── شاشة كاملة ────────────────────────────────────────────────────────
    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    // ── زر الرجوع ──────────────────────────────────────────────────────────
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            // لا تغلق التطبيق بالخطأ - اعرض تأكيد
            new android.app.AlertDialog.Builder(this)
                .setTitle("إغلاق التطبيق")
                .setMessage("هل تريد إغلاق نظام هيا POS؟")
                .setPositiveButton("نعم", (d, w) -> super.onBackPressed())
                .setNegativeButton("لا", null)
                .show();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // بعد منح الصلاحيات، أعد تحميل الصفحة
        if (requestCode == PERMISSION_REQUEST_CODE && webView != null) {
            webView.reload();
        }
    }
}
